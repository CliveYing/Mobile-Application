1. The apk is there in the APK folder and also present in app>release>app-release.apk
2.Code comprises of three Activities.
  	a.login.java(main)
	b.Register.java
	c.DashboardActivity.java
3.It comprises of three layouts respectively.
	a.activity_main.xml
	b.activity_register.xml
	c.activity_dashboard.xml
**********************************************************************************
Steps to run the app.
1.Signup using the asked details and full fill all the requirements.


2.check the email ,if the mail is not present in inbox check in AllMails option of the Email id or check Internet connection.
3. verify the email address by clicking on the link provided.
4.Now sign in with the details you provided.


***********************************************************************************
To run the app on your own database,follow the steps.
1. Add the project to the fire base.
2. Just download the "google-services.jason" provided by the firebase for that particular project you made.
3. Now replace the "google-services.jason" file by the new one in "app" directory.
4. Also in firebase enable the Authentication through email and password in setup method tab.
5. Now the database has been changed to your own database successfully.
