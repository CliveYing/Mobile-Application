package com.example.shiva.try1;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

public class todolistPage extends AppCompatActivity {
    SimpleAdapter simpleAdapter;
    EditText e1;
    TextView t1;
    ListView listView;
    private String user_name,room_name;
    DatabaseReference reference,messagesRef;
    String temp_key;
    LinkedHashMap<String, String> itemDate;
    ArrayList<LinkedHashMap<String, String>> listItems;
    @Override
        protected void onCreate(Bundle savedInstanceState) {
            /**
             *This function is going to run once when the app is installed.
             */
            super.onCreate(savedInstanceState);
            setContentView(R.layout.list_layout);
        Log.i("todoListPage","we are in todolistPage.java");
            e1= (EditText)findViewById(R.id.editText2);
            listItems = new ArrayList<>();
            if(getSupportActionBar()!=null)
            {
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                getSupportActionBar().setDisplayShowHomeEnabled(true);
            }

            listView = findViewById(R.id.listView);
            user_name = getIntent().getExtras().get("user_name").toString();
            room_name = getIntent().getExtras().get("room_name").toString();
//            reference = FirebaseDatabase.getInstance().getReference();
//            reference = FirebaseDatabase.getInstance().getReference().child("Messages");
            DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
            messagesRef = rootRef.child("Messages").child(room_name);
            setTitle(room_name);


//            ValueEventListener valueEventListener = new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                for(DataSnapshot ds : dataSnapshot.getChildren()) {
//                    String date = ds.child("date").getValue(String.class);
//                    String name = ds.child("name").getValue(String.class);
//                    String message = ds.child("msg").getValue(String.class);
////                    String time = ds.child("Time").getValue(String.class);
//                append_chat(date,message,name);
//                    Log.d("TAG", "We discover change"+date+" "+name+" "+message);
//                }
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {}
//        };

//        messagesRef.addListenerForSingleValueEvent(valueEventListener);


            messagesRef.addChildEventListener(new ChildEventListener() {
                @Override
                public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                    append_chat(dataSnapshot);

                }

                @Override
                public void onChildChanged(DataSnapshot dataSnapshot, String s) {
                    append_chat(dataSnapshot);
                }

                @Override
                public void onChildRemoved(DataSnapshot dataSnapshot) {

                }

                @Override
                public void onChildMoved(DataSnapshot dataSnapshot, String s) {
                    append_chat(dataSnapshot);
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });

        }
    public void send(View v)
    {
        Log.i("send","we are starting send function");
        Calendar c = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String formattedDate = df.format(c.getTime());
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> map2 = new HashMap<>();
        map2.put("name",user_name);
        map2.put("msg", e1.getText().toString());
        map2.put("date",formattedDate);
//        messagesRef.child(room_name).push().setValue(map2);
        messagesRef.push().setValue(map2);
        Log.i("test",messagesRef.toString());
        Log.i("test",messagesRef.child("name").toString());
        Log.i("test",messagesRef.child("msg").toString());
        Log.i("test",messagesRef.child("date").toString());
        e1.setText("");

    }

//    public void append_chat(DataSnapshot ss)
    public void append_chat(String date, String msg, String name)
    {
        Log.i("apeend_chat","we are starting append_chat function");
        itemDate = new LinkedHashMap<>();
//        listView.setAdapter(null);


            LinkedHashMap<String, String> resultMap = new LinkedHashMap<>();
//            Map.Entry pair = (Map.Entry) it.next();
            String tempString = name + " "+date;
            resultMap.put("First Line", msg);
            resultMap.put("Second Line", tempString);
            listItems.add(resultMap);
//        }
        Log.i("Check perform", "listItems length is: " + listItems.size());
        String[] from = {"First Line", "Second Line"};
        int[] to = {R.id.text1, R.id.text2};
        simpleAdapter = new SimpleAdapter(this, listItems, R.layout.list_item, from, to);//Create object and
        listView.setAdapter(simpleAdapter);
    }
//    public void append_chat(DataSnapshot ss)
public void append_chat(DataSnapshot ss)
{
    itemDate = new LinkedHashMap<>();


    String chat_msg,chat_username, chat_date;
    Iterator i = ss.getChildren().iterator();
    while(i.hasNext())
    {
        chat_date = ((DataSnapshot) i.next()).getValue().toString();
        chat_msg = ((DataSnapshot) i.next()).getValue().toString();
        chat_username = ((DataSnapshot) i.next()).getValue().toString();

        String secondLine = chat_username+ " "+ chat_date;
        Log.i("appending","firstLine is: "+chat_msg);
        Log.i("appending","secondLine is: "+secondLine);
        itemDate.put(chat_msg,secondLine);
    }
    Iterator it = itemDate.entrySet().iterator();
    while (it.hasNext()) {
        LinkedHashMap<String, String> resultMap = new LinkedHashMap<>();
        Map.Entry pair = (Map.Entry) it.next();
        resultMap.put("First Line", pair.getKey().toString());
        resultMap.put("Second Line", pair.getValue().toString());
        listItems.add(resultMap);
    }
    Log.i("Check perform", "listItems length is: " + listItems.size());
    String[] from = {"First Line", "Second Line"};
    int[] to = {R.id.text1, R.id.text2};
    simpleAdapter = new SimpleAdapter(this, listItems, R.layout.list_item, from, to);//Create object and
    listView.setAdapter(simpleAdapter);
}
}
