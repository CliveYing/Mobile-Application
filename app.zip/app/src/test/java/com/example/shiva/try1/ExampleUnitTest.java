package com.example.shiva.try1;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Example local unit dashboardDummy, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    /**
     * Addition is correct.
     *
     * @throws Exception the exception
     */
    @Test
    public void addition_isCorrect() throws Exception {
        assertEquals(4, 2 + 2);
    }
}